import game.GamePanel;
import game.LevelManager;
import game.DatabaseManager;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        createMainMenu();
    }

    public static void createMainMenu() {
        JFrame mainMenuFrame = new JFrame("Falling Balls Game - Main Menu");
        mainMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainMenuFrame.setSize(400, 300);
        mainMenuFrame.setLayout(new GridLayout(4, 1));

        JLabel welcomeLabel = new JLabel("Welcome to Falling Balls Game!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        mainMenuFrame.add(welcomeLabel);

        JButton startGameButton = new JButton("Start Game");
        JButton viewPlayersButton = new JButton("View Previous Players");
        JButton exitButton = new JButton("Exit");

        mainMenuFrame.add(startGameButton);
        mainMenuFrame.add(viewPlayersButton);
        mainMenuFrame.add(exitButton);

        startGameButton.addActionListener(e -> {
            mainMenuFrame.dispose();
            startGameFlow();
        });

        viewPlayersButton.addActionListener(e -> {
            StringBuilder playerInfo = new StringBuilder("Previous Players:\n\n");
            for (String player : DatabaseManager.loadAllPlayers()) {
                playerInfo.append(player).append("\n");
            }
            JOptionPane.showMessageDialog(null, playerInfo.toString(), "Player Info", JOptionPane.INFORMATION_MESSAGE);
        });

        exitButton.addActionListener(e -> System.exit(0));

        mainMenuFrame.setLocationRelativeTo(null);
        mainMenuFrame.setVisible(true);
    }

    private static void startGameFlow() {
        String name = JOptionPane.showInputDialog("Enter your name:");
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Name cannot be empty!");
            createMainMenu();
            return;
        }

        Object[] levels = { "Easy", "Medium", "Hard" };
        String difficulty = (String) JOptionPane.showInputDialog(
                null,
                "Select Difficulty Level:",
                "Difficulty",
                JOptionPane.PLAIN_MESSAGE,
                null,
                levels,
                "Easy"
        );

        if (difficulty == null) {
            createMainMenu();
            return;
        }

        LevelManager.Level selectedLevel = LevelManager.Level.EASY;
        if ("Medium".equals(difficulty)) {
            selectedLevel = LevelManager.Level.MEDIUM;
        } else if ("Hard".equals(difficulty)) {
            selectedLevel = LevelManager.Level.HARD;
        }
        LevelManager.setLevel(selectedLevel);

        startGame(name, difficulty);
    }

    public static void startGame(String name, String difficulty) {
        JFrame frame = new JFrame("Falling Balls Game");
        GamePanel gamePanel = new GamePanel(
            name,
            difficulty,
            LevelManager.getCurrentLevel(),
            () -> startGame(name, difficulty), // Replay action
            Main::createMainMenu            // Main menu action
        );
        frame.add(gamePanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
