package game;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private static final String FILE_NAME = "player_data.txt";

    // Save player information (name, difficulty, high score)
    public static void savePlayerData(String name, String difficulty, int score) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(name + "," + difficulty + "," + score);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error saving player data: " + e.getMessage());
        }
    }

    // Load all player data
    public static List<String> loadAllPlayers() {
        List<String> players = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                players.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error loading player data: " + e.getMessage());
        }
        return players;
    }
}
