package game;

import java.awt.*;

public class Ball {
    private int x, y, size, fallSpeed;
    private Color color;
    private int panelHeight;

    public Ball(int panelWidth, int panelHeight) {
        this.panelHeight = panelHeight;

        this.size = 20; // Ball size
        this.x = (int) (Math.random() * (panelWidth - size));
        this.y = 0;
        this.fallSpeed = LevelManager.getBallSpeed();

        // Use probability to determine ball color
        double redProbability = LevelManager.getRedBallProbability();
        this.color = Math.random() < redProbability ? Color.RED : Color.YELLOW;
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillOval(x, y, size, size);
    }

    public void fall() {
        y += fallSpeed; // Smaller incremental movements for smooth falling
    }

    public boolean isOutOfScreen() {
        return y > panelHeight;
    }

    public boolean contains(int clickX, int clickY) {
        int centerX = x + size / 2;
        int centerY = y + size / 2;
        return Math.pow(centerX - clickX, 2) + Math.pow(centerY - clickY, 2) <= Math.pow(size / 2, 2);
    }

    public boolean isYellow() {
        return color.equals(Color.YELLOW);
    }
}
