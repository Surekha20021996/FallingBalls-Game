package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GamePanel extends JPanel implements ActionListener {
    private Timer timer;
    private List<Ball> balls;
    private int score;
    private int timeRemaining;
    private String playerName;
    private String difficulty;
    private boolean isGameOver;

    private Runnable replayAction;     // Action for replaying the game
    private Runnable mainMenuAction;  // Action for returning to the main menu

    public GamePanel(String name, String difficulty, LevelManager.Level level, Runnable replayAction, Runnable mainMenuAction) {
        this.playerName = name;
        this.difficulty = difficulty;
        this.replayAction = replayAction;
        this.mainMenuAction = mainMenuAction;
        this.balls = new ArrayList<>();
        this.score = 0;
        this.timeRemaining = 30;
        this.isGameOver = false;

        setBackground(Color.BLACK);
        setFocusable(true);
        setLayout(null);  // Use absolute layout

        timer = new Timer(15, this);
        timer.start();

        // Generate balls at a fixed interval
        new Timer(LevelManager.getBallSpawnFrequency(), e -> {
            if (!isGameOver) {
                generateBall();
            }
        }).start();

        // Mouse listener for ball clicks
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!isGameOver) {
                    checkBallClick(e.getX(), e.getY());
                }
            }
        });

        // Countdown timer for the game
        new Timer(1000, e -> {
            if (!isGameOver) {
                timeRemaining--;
                if (timeRemaining <= 0) {
                    endGame();
                }
                repaint();
            }
        }).start();
    }

    private void generateBall() {
        balls.add(new Ball(getWidth(), getHeight()));
    }

    private void checkBallClick(int x, int y) {
        Iterator<Ball> iterator = balls.iterator();
        while (iterator.hasNext()) {
            Ball ball = iterator.next();
            if (ball.contains(x, y)) {
                if (ball.isYellow()) {
                    score++;
                } else {
                    score--;
                }
                iterator.remove();
                repaint();
                break;
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score, 20, 30);
        g.drawString("Time: " + timeRemaining, getWidth() - 100, 30);

        if (!isGameOver) {
            for (Ball ball : balls) {
                ball.draw(g);
            }
        } else {
            drawGameOverScreen();
        }
    }

    private void drawGameOverScreen() {
        removeAll();

        // Game Over Label
        JLabel gameOverLabel = new JLabel("Game Over!", SwingConstants.CENTER);
        gameOverLabel.setFont(new Font("Arial", Font.BOLD, 40));
        gameOverLabel.setForeground(Color.WHITE);
        gameOverLabel.setBounds(getWidth() / 4, getHeight() / 4, getWidth() / 2, 50);
        add(gameOverLabel);

        // Player Info Label
        JLabel playerInfoLabel = new JLabel(
                "Player: " + playerName + " | Score: " + score,
                SwingConstants.CENTER
        );
        playerInfoLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        playerInfoLabel.setForeground(Color.WHITE);
        playerInfoLabel.setBounds(getWidth() / 4, getHeight() / 4 + 60, getWidth() / 2, 30);
        add(playerInfoLabel);

        // Button Panel for actions
        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        buttonPanel.setBounds(getWidth() / 3, getHeight() / 2, getWidth() / 3, 150);
        buttonPanel.setOpaque(false);  // Transparent background

        // Play Again Button
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setFont(new Font("Arial", Font.BOLD, 20));
        playAgainButton.setFocusPainted(false);
        playAgainButton.addActionListener(e -> replayAction.run());

        // Main Menu Button
        JButton mainMenuButton = new JButton("Main Menu");
        mainMenuButton.setFont(new Font("Arial", Font.BOLD, 20));
        mainMenuButton.setFocusPainted(false);
        mainMenuButton.addActionListener(e -> mainMenuAction.run()); // Correct usage of mainMenuAction

        // Previous Players Button
        JButton previousPlayersButton = new JButton("Previous Players");
        previousPlayersButton.setFont(new Font("Arial", Font.BOLD, 20));
        previousPlayersButton.setFocusPainted(false);
        previousPlayersButton.addActionListener(e -> {
            StringBuilder playerInfo = new StringBuilder("Previous Players:\n\n");
            for (String player : DatabaseManager.loadAllPlayers()) {
                playerInfo.append(player).append("\n");
            }
            JOptionPane.showMessageDialog(null, playerInfo.toString(), "Player Info", JOptionPane.INFORMATION_MESSAGE);
        });

        // Add buttons to the panel
        buttonPanel.add(playAgainButton);
        buttonPanel.add(mainMenuButton); // Main Menu button correctly added here
        buttonPanel.add(previousPlayersButton);

        // Add button panel to the screen
        add(buttonPanel);

        // Update components
        revalidate();
        repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isGameOver) {
            Iterator<Ball> iterator = balls.iterator();
            while (iterator.hasNext()) {
                Ball ball = iterator.next();
                ball.fall();
                if (ball.isOutOfScreen()) {
                    iterator.remove();
                }
            }
            repaint();
        }
    }

    private void endGame() {
        isGameOver = true;
        timer.stop();
        DatabaseManager.savePlayerData(playerName, difficulty, score);
    }
}
