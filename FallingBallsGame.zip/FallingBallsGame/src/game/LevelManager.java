package game;

public class LevelManager {
    public enum Level {
        EASY, MEDIUM, HARD
    }

    private static Level currentLevel = Level.EASY;

    public static void setLevel(Level level) {
        currentLevel = level;
    }

    public static Level getCurrentLevel() {
        return currentLevel;
    }

    public static int getBallSpeed() {
        switch (currentLevel) {
            case EASY:
                return 2; // Slow speed
            case MEDIUM:
                return 5; // Moderate speed
            case HARD:
                return 8; // Fast speed
            default:
                return 2; // Default to EASY
        }
    }

    public static int getBallSpawnFrequency() {
        switch (currentLevel) {
            case EASY:
                return 800; // Spawn every 800ms
            case MEDIUM:
                return 600; // Spawn every 600ms
            case HARD:
                return 400; // Spawn every 400ms
            default:
                return 800;
        }
    }

    public static double getRedBallProbability() {
        switch (currentLevel) {
            case EASY:
                return 0.3; // 30% chance of red ball
            case MEDIUM:
                return 0.5; // 50% chance of red ball
            case HARD:
                return 0.7; // 70% chance of red ball
            default:
                return 0.3;
        }
    }
}
